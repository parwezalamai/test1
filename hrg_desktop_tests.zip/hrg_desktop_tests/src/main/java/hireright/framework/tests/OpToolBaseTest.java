package hireright.framework.tests;

import hireright.framework.common.EnvironmentManager;
import hireright.framework.utils.ScreenShot;
import hireright.framework.utils.allure.AllureLabelExtension;
import hireright.integration_tests.components.common.sdk.logging.CLogger;
import java.util.Optional;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.AfterTestExecutionCallback;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.extension.RegisterExtension;

/**
 * The base class for all OpTool tests which open the tool before each test class in suite and close
 * in after
 */
@ExtendWith(AllureLabelExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public abstract class OpToolBaseTest implements GuiTest {

  private EnvironmentManager settings;

  @RegisterExtension
  AfterTestExecutionCallback callback =
      context -> {
        Optional<Throwable> exception = context.getExecutionException();
        if (exception.isPresent()) {
          ScreenShot.make("On Failure");
        }
      };

  @BeforeAll
  public void setDriver() {
    setupDriver();
  }

  protected void setupDriver() {
    try {
      settings = new EnvironmentManager();
      settings.initialize();
    } catch (Exception e) {
      if (settings != null) {
        settings.cleanup();
      }
    }
    createDriver();
  }

  @AfterAll
  public void teardown() {
    try {
      if (settings != null) {
        settings.cleanup();
      }
    } catch (Exception e) {
      CLogger.log.error("Error during settings cleanup: " + e.getMessage());
    }
    destroyDriver();
  }
}
