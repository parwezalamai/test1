package hireright.framework.tests;

import static org.awaitility.Awaitility.await;

import hireright.framework.pages.login.dialogs.OperatorLoginDialog;
import hireright.framework.pages.optool.OpToolMainPage;
import hireright.framework.utils.WaitService;
import hireright.framework.utils.driver.DriverFactory;
import hireright.framework.utils.driver.DriverSession;
import hireright.integration_tests.components.common.sdk.actions.CCommonActions;
import hireright.integration_tests.components.common.sdk.actions.CWebActions;
import hireright.integration_tests.components.common.sdk.logging.CLogger;
import hireright.integration_tests.components.common.sdk.properties.resolver.CProperties;
import hireright.sdk.util.CStringUtils;
import io.appium.java_client.windows.WindowsDriver;
import io.qameta.allure.Step;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Arrays;
import java.util.Comparator;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

/** Interface for GUI test contains basic feature for windows driver manipulations */
public interface GuiTest {

  String OPTOOL_EXE = "Operator.exe";
  String OPTOOL_TREE_ROOT_XPATH = "//TreeItem[@Name='OpTool']";

  default WindowsDriver createDriver() {
    WindowsDriver driver = DriverFactory.getDriver();
    DriverSession.setCurrentSession(driver);
    return driver;
  }

  default void destroyDriver() {
    try {
      killOpTool();
      if (DriverSession.getCurrentSession() != null) {
        DriverSession.getCurrentSession().quit();
      }
      DriverFactory.resetDriver();
      DriverSession.setCurrentSession(null);
    } catch (WebDriverException e) {
      CLogger.log.warn("Exception during closing the windows driver");
      e.printStackTrace();
    } finally {
      DriverFactory.resetDriver();
      DriverSession.setCurrentSession(null);
    }
  }

  static void killOpTool() {
    try {
      ProcessBuilder processBuilder = new ProcessBuilder("taskkill", "/F", "/IM", OPTOOL_EXE);
      Process process = processBuilder.start();
      int exitCode = process.waitFor();
      if (exitCode != 0 && exitCode != 128) {
        throw new RuntimeException(exitCode + " Exit code. Unable to kill process: " + OPTOOL_EXE);
      } else {
        CLogger.log.info("Successfully killed process: " + OPTOOL_EXE);
      }
    } catch (InterruptedException | IOException e) {
      throw new RuntimeException("Error occurred while killing process: " + OPTOOL_EXE, e);
    }
  }

  static String getOptoolPath() {
    String opToolInstanceName = CWebActions.getOptoolInstance();
    if (!(CStringUtils.isNotEmpty(opToolInstanceName))) {
      throw new IllegalArgumentException("OpTool Server instance is not set.");
    }
    String optoolLocation = getOptoolLocation(opToolInstanceName.toLowerCase());
    CLogger.log.info("OpTool path is : " + optoolLocation);
    return optoolLocation;
  }

  static String getOptoolLocation(String serverName) {
    String optoolPath = null;
    if (StringUtils.isNotEmpty(CProperties.getProperty("OPTOOL_EXE_PATH"))) {
      optoolPath = CProperties.getProperty("OPTOOL_EXE_PATH");
    } else {
      if (StringUtils.isEmpty(CCommonActions.getOptoolPath())) {
        throw new IllegalArgumentException("OPTOOL_LOCATION is not set");
      }
      optoolPath = CCommonActions.getOptoolPath() + "\\" + serverName + "\\optool_proxy";
    }
    String latestRelease = getLatestUpdatedFolder(optoolPath);
    String latestBuild = getLatestUpdatedFolder(optoolPath + "\\" + latestRelease);
    String location =
        optoolPath + "\\" + latestRelease + "\\" + latestBuild + "\\lib\\" + OPTOOL_EXE;
    return location;
  }

  static String getLatestUpdatedFolder(String optoolPath) {
    File dir = new File(optoolPath);
    File[] files = dir.listFiles();
    if (files == null) {
      throw new IllegalArgumentException("Invalid Optool folder path: " + optoolPath);
    } else if (files.length == 0) {
      throw new IllegalArgumentException("Empty Optool Folder: " + optoolPath);
    } else {
      File lastModified =
          (File)
              Arrays.stream(files)
                  .filter(File::isDirectory)
                  .max(Comparator.comparing(File::lastModified))
                  .orElse(null);
      return lastModified.getName();
    }
  }

  static String getWindowsDriverUrl() {
    String windowsDriverUrl;
    String protocol = CProperties.getProperty("WINDOWS_DRIVER_PROTOCOL");
    String host = CProperties.getProperty("WINDOWS_DRIVER_HOST");
    String port = CProperties.getProperty("WINDOWS_DRIVER_PORT");
    if (!(CStringUtils.isNotEmpty(protocol)
        && CStringUtils.isNotEmpty(host)
        && CStringUtils.isNotEmpty(port))) {
      throw new IllegalArgumentException("Windows Driver protocol or host or port is not set.");
    }
    windowsDriverUrl = protocol + "://" + host + ":" + port;
    return windowsDriverUrl;
  }

  static String getOpToolFlg() {
    String opToolFlag = CProperties.getProperty("OPTOOL_FLAG");
    if (CStringUtils.isEmpty(opToolFlag)) {
      throw new IllegalArgumentException("OpTool Flag is not set.");
    }
    return opToolFlag;
  }

  @Step("Login into OpTool")
  default void onlyLoginOpTool(String login, String password, String domain) {
    CLogger.log.info(
        "Login OpTool with Login '"
            + login
            + "', password '"
            + password
            + "' and domain '"
            + domain
            + "'");
    OperatorLoginDialog operatorLoginDialog = new OperatorLoginDialog();
    await("Operator's Login Dialog not displayed")
        .timeout(Duration.ofSeconds(30))
        .pollInterval(Duration.ofMillis(500))
        .ignoreExceptions()
        .until(
            () ->
                operatorLoginDialog.getTitleBars().stream()
                    .anyMatch(e -> e.isDisplayed() && e.getText().contains("Operator's Login")));

    operatorLoginDialog.onlyLogin(login, password, domain);
  }

  @Step("Login into OpTool, with successful login verification")
  default OpToolMainPage loginOpTool(String login, String password, String domain) {
    onlyLoginOpTool(login, password, domain);
    WaitService.sleep(30000);
    await("Unable to login: Operator Tool Tree not displayed")
        .pollInSameThread()
        .timeout(Duration.ofSeconds(120))
        .pollInterval(Duration.ofMillis(500))
        .ignoreExceptions()
        .until(
            () -> {
              WebElement opToolTreeRoot =
                  DriverSession.getCurrentSession().findElement(By.xpath(OPTOOL_TREE_ROOT_XPATH));
              return opToolTreeRoot.isDisplayed();
            });

    CLogger.log.info(
        "Successfully logged in to OpTool with login: "
            + login
            + ", password: "
            + password
            + ", domain: "
            + domain);

    OpToolMainPage opToolMainPage = new OpToolMainPage();
    return opToolMainPage;
  }
}
