package hireright.framework.pages.optool.pane.right.adapters;

import hireright.framework.pages.OpToolBasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AdaptersPane extends OpToolBasePage {

  @FindBy(name = "Reload")
  private WebElement reloadButton;

  public boolean isRightPaneVisible() {
    return reloadButton.isDisplayed();
  }

  public String getRightPaneContent() {
    return reloadButton.getText();
  }

  public void reload() {
    reloadButton.click();
  }
}
