package hireright.framework.pages.optool.pane.left;

import hireright.framework.pages.OpToolBasePage;
import hireright.framework.utils.driver.DriverSession;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OpToolTreePane extends OpToolBasePage {

  @FindBy(xpath = "//TreeItem[@Name='OpTool']")
  private WebElement opToolTreeRoot;

  @FindBy(xpath = "//TreeItem[@Name='OpTool']/TreeItem[@Name='Adapters']")
  private WebElement adaptersTreeItem;

  @FindBy(xpath = "//TreeItem[@Name='OpTool']/TreeItem[@Name='Reports']")
  private WebElement reportTreeItem;

  // Method to click any tree item by name
  public void clickTreeItem(String itemName) {
    String xpath = String.format("//TreeItem[@Name='OpTool']/TreeItem[@Name='%s']", itemName);
    WebElement treeItem = DriverSession.getCurrentSession().findElement(By.xpath(xpath));
    // waitForElementToBeClickable(treeItem);
    treeItem.click();
  }

  // Method to expand tree item
  public void expandTreeItem(String itemName) {
    String xpath = String.format("//TreeItem[@Name='%s']/Button", itemName);
    WebElement expandButton = DriverSession.getCurrentSession().findElement(By.xpath(xpath));
    // waitForElementToBeClickable(expandButton);
    expandButton.click();
  }

  // Get all tree items
  public List<WebElement> getAllTreeItems() {
    return DriverSession.getCurrentSession().findElements(By.xpath("//TreeItem"));
  }

  // Getters for specific items
  public WebElement getReportTreeItem() {
    return reportTreeItem;
  }

  public WebElement getOpToolTreeRoot() {
    return opToolTreeRoot;
  }
}
