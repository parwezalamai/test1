package hireright.framework.pages.optool.menu;

import hireright.framework.pages.OpToolBasePage;
import hireright.framework.utils.driver.DriverSession;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OpToolMenuBar extends OpToolBasePage {

  @FindBy(xpath = "//MenuBar")
  private WebElement menuBar;

  @FindBy(xpath = "//MenuBar/MenuItem")
  private List<WebElement> menuItems;

  @FindBy(xpath = "//MenuBar/MenuItem[@Name='File']")
  private WebElement fileMenu;

  @FindBy(xpath = "//MenuBar/MenuItem[@Name='Edit']")
  private WebElement editMenu;

  @FindBy(xpath = "//MenuBar/MenuItem[@Name='View']")
  private WebElement viewMenu;

  @FindBy(xpath = "//MenuBar/MenuItem[@Name='Tools']")
  private WebElement toolsMenu;

  @FindBy(xpath = "//MenuBar/MenuItem[@Name='Help']")
  private WebElement helpMenu;

  public void clickMenuItem(String menuName) {
    String xpath = String.format("//MenuBar/MenuItem[@Name='%s']", menuName);
    WebElement menuItem = DriverSession.getCurrentSession().findElement(By.xpath(xpath));
    // waitForElementToBeClickable(menuItem);
    menuItem.click();
  }

  public void clickSubMenuItem(String menuName, String subMenuName) {
    clickMenuItem(menuName);
    String xpath =
        String.format("//MenuItem[@Name='%s']/MenuItem[@Name='%s']", menuName, subMenuName);
    WebElement subMenuItem = DriverSession.getCurrentSession().findElement(By.xpath(xpath));
    // waitForElementToBeClickable(subMenuItem);
    subMenuItem.click();
  }

  public List<WebElement> getAllMenuItems() {
    return menuItems;
  }
}
