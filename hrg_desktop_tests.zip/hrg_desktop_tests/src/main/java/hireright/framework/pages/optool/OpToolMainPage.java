package hireright.framework.pages.optool;

import hireright.framework.pages.OpToolBasePage;
import hireright.framework.pages.optool.menu.OpToolMenuBar;
import hireright.framework.pages.optool.pane.left.OpToolTreePane;
import hireright.framework.pages.optool.pane.right.adapters.AdaptersPane;
import hireright.framework.utils.WaitService;

public class OpToolMainPage extends OpToolBasePage {

  private final OpToolTreePane treePane;
  private final AdaptersPane adaptersPane;
  private final OpToolMenuBar menuBar;

  public OpToolMainPage() {
    super();
    treePane = new OpToolTreePane();
    adaptersPane = new AdaptersPane();
    menuBar = new OpToolMenuBar();
  }

  public OpToolTreePane getTreePane() {
    return treePane;
  }

  public AdaptersPane getRightPane() {
    return adaptersPane;
  }

  public OpToolMenuBar getMenuBar() {
    return menuBar;
  }

  public void navigateToTreeItem(String itemName) {
    treePane.clickTreeItem(itemName);
    WaitService.sleep(1000);
  }

  public boolean isRightPaneContentLoaded() {
    return adaptersPane.isRightPaneVisible();
  }
}
