package hireright.framework.pages;

import hireright.framework.utils.driver.DriverSession;
import io.appium.java_client.windows.WindowsDriver;
import org.openqa.selenium.support.PageFactory;

public abstract class OpToolBasePage {

  private final WindowsDriver driver;

  public OpToolBasePage() {
    driver = DriverSession.getCurrentSession();
    PageFactory.initElements(driver, this);
  }
}
