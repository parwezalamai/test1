package hireright.framework.pages.login.dialogs;

import hireright.framework.pages.OpToolBasePage;
import hireright.framework.utils.driver.DriverSession;
import hireright.integration_tests.components.common.sdk.properties.resolver.CProperties;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OperatorLoginDialog extends OpToolBasePage {

  @FindBy(xpath = "//*[@LocalizedControlType='title bar']")
  List<WebElement> titleBars;

  @FindBy(xpath = "//*[@AutomationId='1000']")
  private WebElement loginInput;

  @FindBy(xpath = "//*[@AutomationId='1001']")
  private WebElement passwordInput;

  @FindBy(xpath = "//*[@AutomationId='2150']")
  private WebElement domainInput;

  @FindBy(xpath = "//*[@AutomationId='1860']")
  private WebElement databaseDropdown;

  @FindBy(name = "OK")
  private WebElement okBtn;

  @FindBy(name = "Cancel")
  private WebElement cancelBtn;

  public List<WebElement> getTitleBars() {
    return titleBars;
  }

  public void onlyLogin(String login, String password, String domain) {

    loginInput.clear();
    loginInput.sendKeys(login);
    passwordInput.sendKeys(password);
    domainInput.clear();
    domainInput.sendKeys(domain);
    String opToolInstanceName = CProperties.getProperty("OPTOOL_INSTANCE_NAME");
    if (StringUtils.isNotEmpty(opToolInstanceName)) {
      String database =
          opToolInstanceName.substring(0, 1).toUpperCase()
              + opToolInstanceName.substring(1).toLowerCase()
              + " GCP";
      databaseDropdown.click();
      DriverSession.getCurrentSession().findElementByName(database).click();
    }
    okBtn.click();
  }
}
