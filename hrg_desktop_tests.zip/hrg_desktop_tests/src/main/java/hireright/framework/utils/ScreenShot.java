package hireright.framework.utils;

import hireright.framework.utils.driver.DriverSession;
import hireright.integration_tests.components.common.sdk.logging.CLogger;
import io.qameta.allure.Attachment;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriverException;

public class ScreenShot {
  @Attachment(value = "Screenshot : {name}", type = "image/png")
  public static byte[] make(String name) {
    try {
      if (DriverSession.getCurrentSession() != null) {
        return (DriverSession.getCurrentSession()).getScreenshotAs(OutputType.BYTES);
      } else {
        CLogger.log.warn("Unable to capture screenshot: No active Driver session.");
      }
    } catch (WebDriverException | ClassCastException e) {
      CLogger.log.error("Failed to capture screenshot: " + e.getMessage());
    }
    return new byte[0];
  }
}
