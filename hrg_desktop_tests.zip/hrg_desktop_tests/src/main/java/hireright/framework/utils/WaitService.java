package hireright.framework.utils;

import hireright.framework.utils.constants.TimeoutConstants;
import hireright.framework.utils.driver.DriverSession;
import hireright.integration_tests.components.common.sdk.logging.CLogger;
import io.appium.java_client.windows.WindowsDriver;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;

/** Class contains the different methods which implement custom waits */
public class WaitService {

  private WindowsDriver driver = DriverSession.getCurrentSession();

  private WebElement waitForElement(By locator) {
    return new FluentWait<>(driver)
        .withTimeout(TimeoutConstants.SHORT_TIMEOUT, TimeUnit.MILLISECONDS)
        .pollingEvery(TimeoutConstants.VERY_SHORT_TIMEOUT, TimeUnit.MILLISECONDS)
        .ignoring(NoSuchElementException.class)
        .ignoring(StaleElementReferenceException.class)
        .until(
            driver -> {
              WebElement element = driver.findElement(locator);
              if (element.isDisplayed() && element.isEnabled()) {
                return element;
              }
              throw new NoSuchElementException("Element not visible or enabled");
            });
  }

  /**
   * Sleep the thread for several milliseconds. Logs it if sleep is longer than 1 seconds
   *
   * @param l - milliseconds to sleep
   */
  public static void sleep(long l) {
    if (l > 1000) {
      StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
      StackTraceElement stackTraceElement = stackTrace[2];
      CLogger.log.info(
          String.format(
              "%s:%s Waiting for %.2f seconds",
              stackTraceElement.getFileName(),
              stackTraceElement.getLineNumber(),
              ((float) l) / 1000));
    }
    try {
      Thread.sleep(l);
    } catch (InterruptedException e) {
      CLogger.log.warn("Thread was interrupted while sleeping", e);
    }
  }
}
