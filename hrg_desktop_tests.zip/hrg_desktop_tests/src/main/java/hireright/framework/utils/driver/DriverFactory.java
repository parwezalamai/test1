package hireright.framework.utils.driver;

import hireright.framework.tests.GuiTest;
import io.appium.java_client.windows.WindowsDriver;
import java.net.MalformedURLException;
import java.net.URI;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.DesiredCapabilities;

public class DriverFactory {
  private static WindowsDriver driver = null;

  private static WindowsDriver createDriver() {
    try {
      String opToolExePath = GuiTest.getOptoolPath();
      String windowsDriverUrl = GuiTest.getWindowsDriverUrl();
      String opToolFlag = GuiTest.getOpToolFlg();

      DesiredCapabilities capabilities = new DesiredCapabilities();
      capabilities.setCapability("app", opToolExePath);
      capabilities.setCapability("appArguments", opToolFlag);
      driver = new WindowsDriver(URI.create(windowsDriverUrl).toURL(), capabilities);
      //      driver
      //          .manage()
      //          .timeouts()
      //          .implicitlyWait(TimeoutConstants.VERY_SHORT_TIMEOUT, TimeUnit.MILLISECONDS);
      return driver;
    } catch (WebDriverException | MalformedURLException e) {
      e.printStackTrace();
      throw new RuntimeException("Driver Creation failed", e);
    }
  }

  public static WindowsDriver getDriver() {
    return createDriver();
  }

  public static void resetDriver() {
    if (driver != null) {
      driver.quit();
      driver = null;
    }
  }
}
