package hireright.framework.utils.driver;

import io.appium.java_client.windows.WindowsDriver;

public class DriverSession {

  private static ThreadLocal<WindowsDriver> currentSession = new ThreadLocal<WindowsDriver>();

  public static WindowsDriver getCurrentSession() {
    return currentSession.get();
  }

  public static void setCurrentSession(WindowsDriver newSession) {
    currentSession.set(newSession);
  }
}
