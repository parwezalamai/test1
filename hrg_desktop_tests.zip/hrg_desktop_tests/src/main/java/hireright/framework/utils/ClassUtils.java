package hireright.framework.utils;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.stream.Stream;

public class ClassUtils {

  /**
   * Create new class instance
   *
   * @param clazz the Class to create instance of
   * @param params the parameter array
   * @param <T> the Class type
   * @return new instance of Class
   */
  public static <T> T newInstance(Class<T> clazz, Object... params) {
    Class<?>[] parameterTypes = Stream.of(params).map(p -> p.getClass()).toArray(Class[]::new);
    return newInstance(clazz, parameterTypes, params);
  }

  /**
   * Create new class instance
   *
   * @param clazz the Class to create instance of
   * @param params the parameter array
   * @param <T> the Class type
   * @return new instance of Class
   */
  public static <T> T newInstance(Class<T> clazz, Class<?>[] parameterTypes, Object... params) {
    try {
      Constructor<T> constructor = getConstructor(clazz, parameterTypes);
      return constructor.newInstance(params);
    } catch (SecurityException
        | InstantiationException
        | IllegalAccessException
        | IllegalArgumentException
        | InvocationTargetException e) {
      Throwable cause = e.getCause();
      if (cause instanceof RuntimeException) {
        throw (RuntimeException) cause;
      } else {
        throw new RuntimeException(e);
      }
    }
  }

  /**
   * Create new class instance
   *
   * @param clazz the Class to create instance of
   * @param <T> the Class type
   * @return new instance of Class
   */
  public static <T> T newInstance(Class<T> clazz) {
    return newInstance(clazz, new Object[] {});
  }

  /**
   * Get constructor by types
   *
   * @param clazz the Class to create instance of
   * @param parameterTypes types of constructor parameters
   * @param <T> the Class type
   * @return Constractor
   */
  private static <T> Constructor<T> getConstructor(Class<T> clazz, Class<?>[] parameterTypes) {
    try {
      Constructor<T> constructor = clazz.getConstructor(parameterTypes);
      return constructor;
    } catch (NoSuchMethodException | SecurityException e) {
      throw new RuntimeException(e);
    }
  }
}
