package tests.selftest;

import hireright.framework.pages.optool.OpToolMainPage;
import hireright.framework.tests.OpToolBaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.TmsLink;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class OpToolNavigationTest extends OpToolBaseTest {

  //  @Test
  //  public void testDatabaseNavigation() {
  //    OpToolMainPage mainPage = new OpToolMainPage();
  //
  //    // Navigate to Database tree item
  //    mainPage.navigateToTreeItem("Database");
  //
  //    // Verify right pane is loaded
  //    assert mainPage.isRightPaneContentLoaded() : "Right pane not loaded";
  //
  //    // Navigate to specific adapter
  //    mainPage.getLeftPane().expandTreeItem("Ackpoint");
  //    mainPage.navigateToTreeItem("Adapters");
  //
  //    // Use menu bar
  //    mainPage.getMenuBar().clickMenuItem("View");
  //    mainPage.getMenuBar().clickSubMenuItem("View", "Refresh");
  //  }

  @Test
  @TmsLink("HRG-17011")
  @DisplayName("Sample test for navigation")
  @Description("Verify successful navigation")
  public void testUsageSection() {
    OpToolMainPage mainPage = loginOpTool("system", "123", "ADMIN");

    mainPage.navigateToTreeItem("Adapters");
    mainPage.getRightPane().reload();

    //    // Navigate to Usage section
    //    mainPage.navigateToTreeItem("Adapters");
    //    mainPage.navigateToTreeItem("BGCOUT");
    //
    //    // Verify content in right pane
    //    String content = mainPage.getRightPane().getRightPaneContent();
    //    assert content.contains("Background Check") : "Wrong content displayed";

  }
}
