package tests.selftest;

import hireright.framework.tests.OpToolBaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.TmsLink;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class SampleTest extends OpToolBaseTest {

  @Test
  @TmsLink("HRG-17011")
  @DisplayName("Sample test for login")
  @Description("Verify successful login to OpTool")
  public void testLoginOpTool() {
    loginOpTool("system", "123", "ADMIN");
  }
}
